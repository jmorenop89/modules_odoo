from odoo import models,fields, api

class ResPartner(models.Model):
    #Inherits from partner model
    _inherit =  'res.partner'
    x_commercial_name = fields.Char(string = 'Nombre Comercial')